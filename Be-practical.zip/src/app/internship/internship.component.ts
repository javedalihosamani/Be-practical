import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';

@Component({
  selector: 'app-internship',
  templateUrl: './internship.component.html',
  styleUrls: ['./internship.component.sass']
})
export class InternshipComponent implements OnInit {

  panelOpenState = false;
  constructor() { }

  name = new FormControl('', [Validators.required]);
  mobile = new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(12)]);
  email = new FormControl('', [Validators.required, Validators.email]);

  getEmailError() {
    return this.email.hasError('required') ? 'You must enter a value' :
        this.email.hasError('email') ? 'Not a valid email' :
            '';
  }

  getNameError() {
    return this.name.hasError('required') ? 'You must enter a name' : '';
  }

  getMobileError(){
    return this.mobile.hasError('required') ? 'You must enter a mobile number' :
    this.mobile.hasError('minlength') ? 'You are entered less than 10 digits' :
    this.mobile.hasError('maxlength') ? 'You are entered more than 10 digits' : '';
  }

  ngOnInit() {
  }

}
