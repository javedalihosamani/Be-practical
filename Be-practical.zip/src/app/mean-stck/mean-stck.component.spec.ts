import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MeanStckComponent } from './mean-stck.component';

describe('MeanStckComponent', () => {
  let component: MeanStckComponent;
  let fixture: ComponentFixture<MeanStckComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MeanStckComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MeanStckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
