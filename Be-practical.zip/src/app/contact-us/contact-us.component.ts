import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.sass']
})
export class ContactUsComponent implements OnInit {
  name = new FormControl('', [Validators.required]);
  mobile = new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(12)]);
  email = new FormControl('', [Validators.required, Validators.email]);

  getEmailError() {
    return this.email.hasError('required') ? 'You must enter a value' :
        this.email.hasError('email') ? 'Not a valid email' :
            '';
  }

  getNameError() {
    return this.name.hasError('required') ? 'You must enter a name' : '';
  }

  getMobileError(){
    return this.mobile.hasError('required') ? 'You must enter a mobile number' :
    this.mobile.hasError('minlength') ? 'You are entered less than 10 digits' :
    this.mobile.hasError('maxlength') ? 'You are entered more than 10 digits' : '';
  }
  constructor() { }

  ngOnInit() {
  }

}
