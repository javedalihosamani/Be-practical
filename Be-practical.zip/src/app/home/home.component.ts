import {  Component,  OnInit} from '@angular/core';
declare let AOS: any;
declare let TiltSlider: any;
declare let $: any;
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.sass']
})
export class HomeComponent implements OnInit {

  constructor() {}
  ngOnInit() {
    AOS.init();
    // tslint:disable-next-line: no-unused-expression
    new TiltSlider(document.getElementById('slideshow'));
    $(() => {

      const cycleTime = 5000;
      let intervalId;

      function cycleImage() {
          $('nav>.current').next().trigger('click');
          // tslint:disable-next-line: triple-equals
          if ($('nav > .current').next().index() == '-1') {
              $('nav > span').trigger('click');
          }
      }

      $('#slideshow').on('mouseover', () => {
          clearInterval(intervalId);
      });

      $('#slideshow').on('mouseout', () => {
          clearInterval(intervalId);
          intervalId = setInterval(cycleImage, cycleTime);
      });

      intervalId = setInterval(cycleImage, cycleTime);
  });
    const owl = $('.owl-carousel');
    owl.owlCarousel({
    items: 4,
    loop: true,
    margin: 10,
    autoplay: true,
    autoplayTimeout: 3000,
    autoplayHoverPause: true
  });
    $('.play').on('click', () => {
    owl.trigger('play.owl.autoplay', [1000]);
  });
    $('.stop').on('click', () => {
    owl.trigger('stop.owl.autoplay');
  });
  }
}
