import {  Component,  OnInit} from '@angular/core';
import {  NgxSpinnerService } from 'ngx-spinner';
declare var $: any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.sass']
})
export class AppComponent implements OnInit {
  title = 'Be-practical';

  constructor(private spinnerService: NgxSpinnerService) {}

  ngOnInit() {
    this.spinner();
  }
  spinner(): void {
    this.spinnerService.show();
    setTimeout(() => {
      this.spinnerService.hide();
    }, 1500);
  }
}
